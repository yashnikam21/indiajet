package com.controller;

/**
 * Admin controller to handle flow of data.
 */
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dao.UserDao;
import com.model.Flight;
import com.model.Login;
import com.model.MD5;
import com.model.User;
import com.service.UserService;;

@Controller
public class AdminController {
	@Autowired
	private UserDao userDao;
	@Autowired
	UserService userService;

	/**
	 * 
	 * @return to FlightDetails page
	 */
	@RequestMapping(value = "/addflight1", method = RequestMethod.GET)
	public ModelAndView addflight1() {
		return new ModelAndView("flightdetails");
	}

	/**
	 * 
	 * @param model
	 * @return object model and to DisplayFlight page with listFlight
	 * @throws IOException
	 */
	@RequestMapping(value = "/viewflight")
	public ModelAndView listFlight(ModelAndView model) throws IOException {
		try {
			List<Flight> listFlight = userDao.list();
			model.addObject("message", "Welcome to spring");
			model.addObject("listFlight", listFlight);
			model.setViewName("displayflight");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return object mav
	 */
	@RequestMapping(value = "/adminlogin", method = RequestMethod.GET)
	public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("adminlogin");
		mav.addObject("user", new User());
		
		return mav;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @param login
	 * @return ModelAndView object mv and redirect to admin
	 */
	@RequestMapping(value = "/adminloginProcess", method = RequestMethod.POST)
	public ModelAndView adminlogin(@ModelAttribute("login") Login login) {
		System.out.println("in admimlogincon");
		ModelAndView mv = null;
		System.out.println("adm cnt"+login.getEmail()+""+login.getPassword());
		if (login.getEmail().equals("admin") && login.getPassword().equals(MD5.getMd5("admin"))) {
			mv = new ModelAndView("admin");
		} else {
			mv = new ModelAndView("loginerror");
			mv.addObject("message", "<h1>Username or Password is wrong!!</h1>");
		}
		return mv;
		/* return new ModelAndView("welcome", "firstname", user.getFname()); */
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView object
	 */
@RequestMapping(value = "/book", method = RequestMethod.GET)
	public ModelAndView book() {
		return new ModelAndView("noofpassengers");
	}

	/**
	 * 
	 * @return ModelAndView object and to forgot page
	 */
	@RequestMapping(value = "/forget")
	public ModelAndView forget() {
		return new ModelAndView("forget");
	}

	@RequestMapping(value = "/adminlogout")
	public ModelAndView Logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		session.invalidate();
		return new ModelAndView("login");
	}
}
