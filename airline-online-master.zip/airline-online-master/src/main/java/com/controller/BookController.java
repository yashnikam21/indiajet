package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
/**
 * Controller to handle No of passengers during booking process
 */
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Seat;
import com.service.UserService;

@Controller
public class BookController {
	@Autowired
	UserService userservice;
	/**
	 * 
	 * @param request
	 * @param response
	 * @return to NoOfPassengers page
	 */
	@RequestMapping(value = "/load/{flightnumber}", method = RequestMethod.GET)
	public ModelAndView load(@PathVariable("flightnumber") String flightnumber, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("hi: " + flightnumber);
		HttpSession session = request.getSession(true);
		session.setAttribute("no1", flightnumber);
		return new ModelAndView("loading");
	}

	/**
	 * 
	 * @param value
	 * @return ModelAndView object and value to SeatSelection page
	 */
	@RequestMapping(value = "/seat")
	public ModelAndView seat(@RequestParam("sel") String value
			,HttpServletRequest request,
			ModelAndView model) {
		List<Seat> al=userservice.retri();
		model.addObject("listseat",al);
		model.addObject("msg",value);
		model.setViewName("seatselection");
		return model;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView object to Payment page
	 */
	@RequestMapping(value = "/load1")
	public ModelAndView load1(ModelAndView model) {
		model.setViewName("loading1");
		return model;
	}
	
	@RequestMapping(value = "/success")
	public ModelAndView success(ModelAndView model) {
		model.setViewName("success");
		return model;
	}
	@RequestMapping(value = "/payment")
	public ModelAndView payment(@RequestParam(value="chkbx") String no,
			HttpServletRequest request,ModelAndView model) {
		/*System.out.println("Number: "+no);*/

		HttpSession session=request.getSession();
		String no1=session.getAttribute("no1").toString();
		List<Seat> al=userservice.retri();
		model.addObject("listseat",al);
		System.out.println("data:"+al);
		model.addObject("no1",no);
		model.setViewName("payment");
		userservice.book(no,no1);
		return model;
	}
}
